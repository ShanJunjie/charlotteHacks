package unccHack;


import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {
    @RequestMapping("/api/people")
    public String getPeople() {
    	List<String> stringList;
		try {
			stringList = FileReader.readFile("facebookUserOutput.txt");
		
			StringBuffer stringBuffer = new StringBuffer();
			for(String string : stringList) {
				stringBuffer.append(string);
			}
			return stringBuffer.toString();
		} catch (IOException e) {
			
			e.printStackTrace();
			return null;
		}
    }
    @RequestMapping("/api/event")
    public String getEvent() {
    	List<String> stringList;
		try {
			stringList = FileReader.readFile("facebookEventOutput.txt");
		
			StringBuffer stringBuffer = new StringBuffer();
			for(String string : stringList) {
				stringBuffer.append(string);
			}
			return stringBuffer.toString();
		} catch (IOException e) {
			
			e.printStackTrace();
			return null;
		}
    }
}

