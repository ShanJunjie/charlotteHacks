package edu.uncc.Hack.TechWomen;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RunCrawlerApp {	
	public static void main(String[] args) throws JsonProcessingException {
		String fileName = "facebookName.txt";
		FacebookCrawler facebookCrawler = new FacebookCrawler();		
		
		facebookCrawler.fetchUsers(fileName);
		ObjectMapper mapper = new ObjectMapper();
		FileWriter.writeFile("facebookUserOutput.txt", mapper.writeValueAsString(facebookCrawler.getFacebookUsers()));
		facebookCrawler.fetchEvents();
		mapper = new ObjectMapper();
		FileWriter.writeFile("facebookEventOutput.txt", 
				mapper.writeValueAsString(facebookCrawler.getFacebookEvents()));
				
	}
}
