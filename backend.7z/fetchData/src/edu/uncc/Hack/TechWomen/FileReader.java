package edu.uncc.Hack.TechWomen;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileReader {
	
	static public List<String> readFile(String file) throws IOException {
		BufferedReader reader = new BufferedReader(
				new java.io.FileReader(file));
		String oneline;
		List<String> result = new ArrayList<>();
		
		try {
			while( ( oneline = reader.readLine()) != null) {
				result.add(oneline);
			}
			reader.close();
			return result;
		} finally {
			reader.close();
		}
	
	}
}
