package edu.uncc.Hack.TechWomen;

public class PinterestPost {
	public String imgSrc;
	public String pinURL;
	public String title;
	public String description;
	public String pinCount;
	public String likeCount;
	public String comment;
}
