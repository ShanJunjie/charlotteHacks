package edu.uncc.Hack.TechWomen;

import java.io.BufferedWriter;
import java.io.IOException;

public class FileWriter {
	static public void writeFile(String file, String outputString) {
		BufferedWriter writer = null;
		try	{
		    writer = new BufferedWriter( new java.io.FileWriter( file));
		    writer.write( outputString);
		} catch (IOException e) {
		} finally {
		    try {
		        if ( writer != null)
		        	writer.close( );
		    } catch (IOException e) {
		    }
		}
		
	}
}
