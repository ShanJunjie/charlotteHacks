package edu.uncc.Hack.TechWomen;

import static java.lang.String.format;
import static java.lang.System.currentTimeMillis;
import static java.lang.System.out;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.css.ElementCSSInlineStyle;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.restfb.Connection;
import com.restfb.DefaultFacebookClient;
import com.restfb.DefaultJsonMapper;
import com.restfb.Facebook;
import com.restfb.FacebookClient;
import com.restfb.JsonMapper;
import com.restfb.Parameter;
import com.restfb.Version;
import com.restfb.json.JsonArray;
import com.restfb.json.JsonObject;
import com.restfb.types.Page;
import com.restfb.types.Post;
import com.restfb.types.Url;
import com.restfb.types.User;
import com.restfb.types.Event;


public class FacebookCrawler {
	private List<FacebookUser> facebookUsers;
	private List<FacebookEvent> facebookEvents;
	
	  /**
	   * RestFB Graph API client.
	   */
	private final FacebookClient facebookClient23;
	private final FacebookClient facebookClient20;
	
	private static final String ACCESS_TOKEN = "CAACEdEose0cBANw4srHUQSCmVf5GQZBU4ZC6HUmUzDtAxW6Mfly5ZAgPmd8AlsTwcqOLHdrZBc142mv9b8rfZALPNcqEzz2YTQKoyi8HY7rfhWDfgSplJuPbnlA0gb5BIr1BShesLfUKZC5YWT6h4bpnzW5ON9qFaCYEhoMPia1ZCcF0U0aGZCZAGR1GP6f90wKRB7oTIgZCmziwZDZD";
	
	public FacebookCrawler() {
		super();
		facebookEvents = new ArrayList<>();
		facebookUsers = new ArrayList<>();
		facebookClient23 = new DefaultFacebookClient(ACCESS_TOKEN, Version.VERSION_2_3);
		facebookClient20 = new DefaultFacebookClient(ACCESS_TOKEN, Version.VERSION_2_0);
	}
	public FacebookCrawler(String access_token) {
		super();
		facebookEvents = new ArrayList<>();
		facebookUsers = new ArrayList<>();
		facebookClient23 = new DefaultFacebookClient(access_token, Version.VERSION_2_3);
		facebookClient20 = new DefaultFacebookClient(ACCESS_TOKEN, Version.VERSION_2_0);
	}
	public List<FacebookUser> getFacebookUsers() {
		return facebookUsers;
	}
	public List<FacebookEvent> getFacebookEvents() {
		return facebookEvents;
	}	
	private void assignJsonToFacebookUser(JsonObject object) {
		FacebookUser facebookUser = new FacebookUser();
		FacebookPost facebookPost = new FacebookPost();
		facebookPost.setSharesCount(object.getString("pinCount"));
		facebookPost.setPostURL(object.getString("pinURL"));
		facebookPost.setDescription(object.getString("description"));
		facebookPost.setLikesCount(object.getString("likeCount"));
		facebookPost.setPictureURL(object.getString("imgSrc"));
		facebookPost.setCaption(object.getString("title"));
		List<FacebookPost> posts = new ArrayList<>();
		posts.add(facebookPost);
		facebookUser.setPosts(posts);
		this.facebookUsers.add(facebookUser);
	}
	private void fetchPinterest() {
		try {
			List<String> strings = FileReader.readFile("pinterestJSON.txt");
			JsonObject jsonObject = new JsonObject(strings.get(0));
			JsonArray jsonArray = jsonObject.getJsonArray("posts");
			for(int i = 0; i < jsonArray.length(); ++ i) {
				JsonObject object = jsonArray.getJsonObject(i);
				assignJsonToFacebookUser(object);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void fetchUsers(String fileName) {
		fetchPinterest();
		List<String> userNames;		
		try {
			userNames = FileReader.readFile(fileName);
		
			for(String userName : userNames) {
				this.facebookUsers.add( fetchUser(userName));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void fetchEvents() {
		  Connection<Event> eventList =
				  facebookClient23.fetchConnection("search", Event.class,
				    Parameter.with("q", "TechWomen"),
				    Parameter.with("type", "event"),
				    Parameter.with("center", "35.22, -80.84"),
				  	Parameter.with("distance", "100"));		  
		  for(Event event : eventList.getData()) {
			  FacebookEvent facebookEvent = new FacebookEvent();
			  facebookEvent.setName(event.getName());
			  facebookEvent.setPictureURL(event.getPicture());
			  if (event.getStartTime() != null) {
				  facebookEvent.setStartTime(Long.toString(event.getStartTime().getTime()/1000));
			  }
			  
			  if(event.getEndTime() != null) {
				  facebookEvent.setEndTime(Long.toString(event.getEndTime().getTime()/1000));
			  }
			  facebookEvent.setDescription(event.getDescription());
			  facebookEvent.setLocation(event.getLocation());
			  facebookEvents.add(facebookEvent);
		  }
	  }
	
	private FacebookUser fetchUser(String userName) {

	    Page page = facebookClient23.fetchObject(userName, Page.class);
		User user = facebookClient23.fetchObject(userName, User.class);
	    FacebookUser facebookUser = new FacebookUser();
	    facebookUser.setUserName(userName);
	    facebookUser.setFirstName(user.getFirstName());
	    facebookUser.setLastName(user.getLastName());
	    if(page.getLocation() != null) {	    	
	    	facebookUser.setCity(page.getLocation().getCity());
	    }
	    if(page.getLocation() != null && page.getLocation().getLatitude() != null) {
	    	facebookUser.setLatitude(page.getLocation().getLatitude().toString());
	    	facebookUser.setLongitude(page.getLocation().getLongitude().toString());
	    }
	    facebookUser.setAbout(user.getAbout());
	    if(page.getCover() != null)
	    	facebookUser.setCoverPicURL(page.getCover().getSource());
	    facebookUser.setPosts( fetchPosts(userName) );  	    
	    
	    return facebookUser;
	}
	
	private List<FacebookPost> fetchPosts(String userName) {	
		Connection<Post> myFeed = facebookClient23.fetchConnection(userName + "/feed", Post.class);
		List<FacebookPost> facebookPosts = new ArrayList<>();
		for(Post post: myFeed.getData()) {
	    	//if(post.getFrom().getName().equals(userName)) {
	    	if(true) {
	    		FacebookPost fbPost = new FacebookPost();
	    		fbPost.setName(post.getName());
	    		fbPost.setCaption(post.getCaption());
	    		fbPost.setMessage(post.getMessage());
	    		fbPost.setCreateTime(Long.toString(post.getCreatedTime().getTime()/1000));
	    		fbPost.setDescription(post.getDescription());
	    		fbPost.setPictureURL(post.getPicture());
	    				
	    		if (post.getLikes() != null) {
	    			fbPost.setLikesCount(Integer.toString(post.getLikes().getData().size()));
				} else {
					fbPost.setLikesCount("0");
				}
	    		if (post.getComments() != null) {
	    			fbPost.setCommentsCount(Integer.toString(post.getComments().getData().size()));
				} else {
					fbPost.setCommentsCount("0");
				}
	    		if (post.getShares() != null) {
	    			fbPost.setSharesCount(Long.toString(post.getShares().getCount()));
	    		} else {
	    			fbPost.setSharesCount("0");
	    		}
	    		
	    		if (post.getActions().size() > 0) {
	    			fbPost.setPostURL(post.getActions().get(0).getLink());
	    		}
	    		facebookPosts.add(fbPost);
	    	}
		}
	    return facebookPosts;
	}
	
}
