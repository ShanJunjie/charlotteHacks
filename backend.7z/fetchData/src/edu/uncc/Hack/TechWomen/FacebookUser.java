package edu.uncc.Hack.TechWomen;

import java.util.ArrayList;
import java.util.List;

public class FacebookUser {
	public FacebookUser() {
		super();
		this.posts = new ArrayList<FacebookPost>();
	}
	private String userName;
	private String firstName, lastName;
	private String city;
	private String latitude;
	private String longitude;
	private String about;
	private String coverPicURL;
	private List<FacebookPost> posts;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public String getCoverPicURL() {
		return coverPicURL;
	}
	public void setCoverPicURL(String coverPicURL) {
		this.coverPicURL = coverPicURL;
	}
	public List<FacebookPost> getPosts() {
		return posts;
	}
	public void setPosts(List<FacebookPost> posts) {
		this.posts = posts;
	}
	
	
}
